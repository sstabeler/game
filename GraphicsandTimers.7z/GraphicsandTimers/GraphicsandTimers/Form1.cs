﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphicsandTimers
{
    

    public partial class frmTimers : Form
    {
        public frmTimers()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.DoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            this.UpdateStyles();
        }

        public Point p;
        
        public Random rnd = new Random(); //declaration of random generator
        public circle newcircle; //circle generation
        public List<circle> circlelist = new List<circle>();
        public int score = new int(); //declaration of user score
        Rectangle PlayerRectangle; //creating rectangle on form
        Region PlayerShape; 

        private void tmrCircles_Tick(object sender, EventArgs e) //tmrCircle tick event
        {
            p.X = rnd.Next(1, this.ClientSize.Width - 20);
            p.Y = rnd.Next(1, this.ClientSize.Height - 20);
            newcircle = new circle(p.X, p.Y, 10, Brushes.Blue); 
            circlelist.Add(newcircle);
            Refresh(); //refresh the form each time a circle is added
            if (circlelist.Count() == 0) //number of circles needed to win
            {
                tmrCircles.Stop(); //stoping the timer
                MessageBox.Show("You Win! Your score is:" + score); //showing confirmation dialog box
            }
            else if (circlelist.Count() == 12) //number of circles needed to lose the game
            {
                tmrCircles.Stop(); //stoping the timer
                MessageBox.Show("You Lose. Your score is:" + score); //showing confirmation dialog box
            }
        }

        private void btnGo_MouseClick(object sender, MouseEventArgs e) //Start Game/Reset button event
        {
            circlelist = new List<circle>();
            score = new int(); //reset score on button press, during reseting of the game
            tmrCircles.Start(); //initiating the timer on button click
             
        }
        private void frmTimers_Paint(object sender, PaintEventArgs e)
        {
            PlayerRectangle = new Rectangle(X, Y, s, s);
            PlayerShape = new Region(PlayerRectangle);
            
            e.Graphics.FillRectangle(Brushes.Red,PlayerRectangle);
            
            for (int i = 0; i < circlelist.Count(); i++)
            {
                circle c = circlelist[i];
                Region circle = new Region(new Rectangle(c.x, c.y, c.r * 2, c.r * 2));
                circle.Intersect(PlayerShape); //detecting interaction with circles

                if (circle.GetRegionScans(new Matrix(1, 0, 0, 1, 0, 0)).Length > 0)
                {
                    circlelist.Remove(circlelist[i]); //removing circle from screen
                    score += 1; //adds one onto user score once they have collected a circle
                    Refresh(); 

                }
                else
                {
                    e.Graphics.FillRectangle(c.b, c.x, c.y, c.r * 2, c.r * 2);
                }
                     
            }
            
            
        }

        public int X = 250, Y = 250;

        public const int d = 3, s = 100;

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData) //custom event allowing for use of button on the form
        {
            switch (keyData)
            {
                case Keys.Up: //permits the use of the Up arrow key
                    if (Y >= d)
                        Y -= d;
                    else
                        Y = 0;
                    break;
                case Keys.Down://permits the use of the Down arrow key
                    if (Y + s <= this.ClientSize.Height - d)
                        Y += d;
                    else
                        Y = this.ClientSize.Height - s;
                    break;
                case Keys.Left: //permits the use of the Left arrow key
                    if (X >= d)
                        X -= d;
                    else
                        X = 0;
                    break;
                case Keys.Right: //permits the use of the Right arrow key
                    if (X + s <= this.ClientSize.Width - d)
                        X += d;
                    else
                        X = this.ClientSize.Width - s;
                    break;
                case Keys.PageUp: //permits the use of the Page Up key
                    if (Y >= d && X + s <= this.ClientSize.Width - d)
                    {
                        Y -= d;
                        X += d;
                    }
                    else
                    {
                        if (Y < d)
                            Y = 0;
                        if (X + s > this.ClientSize.Width - s)
                            X = this.ClientSize.Width - s;
                    }
                    break;
                case Keys.PageDown: //permits the use of the Page Down key
                    if (Y + s <= this.ClientSize.Height - d && X + s <= this.ClientSize.Width - d)
                    {
                        Y += d;
                        X += d;
                    }
                    else
                    {
                        if (Y + s > this.ClientSize.Height - d)
                            Y = this.ClientSize.Height - s;
                        if (X + s > this.ClientSize.Width - d)
                            X = this.ClientSize.Width - s;
                    }
                    break;
                case Keys.End: //permits the use of the End key
                    if (X >= d && Y + s <= this.ClientSize.Height - d)
                    {
                        Y += d;
                        X -= d;
                    }
                    else
                    {
                        if (X < d)
                            X = 0;
                        if (Y + s > this.ClientSize.Height - d)
                            Y = this.ClientSize.Height - s;
                    }
                    break;
                case Keys.Home: //permits the use of the Home key
                    if (Y >= d && X >= d)
                    {
                        Y -= d;
                        X -= d;
                    }
                    else
                    {
                        if (Y < d)
                            Y = 0;
                        if (X < d)
                            X = 0;
                    }
                    break;
                default:
                    return base.ProcessCmdKey(ref msg, keyData);
            }
            Refresh();
            return true;
        
    }
        public class circle //class declaring circles
        {
            public int x;  //declaration of X co-ordinate
            public int y; //declaration of Y co-ordinate
            public int r;
            public Brush b; //declaration of brush variable

            public circle(int _x, int _y, int _r, Brush _b)
            {
                x = _x;  // x coordinate
                y = _y;  // y coordinate
                r = _r;  // radius
                b = _b;  // brush color
            }
        }

    }
}
